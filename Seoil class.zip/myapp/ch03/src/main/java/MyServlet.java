

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class MyServlet
 */
@WebServlet("/MyServlet")
public class MyServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//service메서드의 두번째 매개변수인 response는 내장객체
		response.setContentType("text/html;charset=utf-8"); //응답정보 html 사용문자 utf-8
		PrintWriter out = response.getWriter();
		out.println("<html>");
		out.println("<head>");
		out.println("<title>MyServlet</title>");
		out.println("</head>");
		out.println("<body>");
		out.println("<h1> 파이팅 코리아 </h1>");
		out.println("</body>");
		out.println("</html>");
		//http://localhost/ch03/MyServlet 도메인주소가 이처럼 표시되는 이유는 urlmapping이 되었기 때문이다. 
	}
}
