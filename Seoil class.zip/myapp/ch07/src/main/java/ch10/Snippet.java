package ch10;

public class Snippet {
	public static void main(String[] args) {
	}
}

