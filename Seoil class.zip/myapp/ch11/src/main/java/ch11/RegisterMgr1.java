package ch11;

import java.util.Vector;
import java.sql.*;
import java.sql.DriverManager;
public class RegisterMgr1 {
	private final String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";
	private final String JDBC_URL = "jdbc:mysql://localhost:3306/mydb?serverTimezone=UTC";
	private final String USER = "root";
	private final String PASS = "password";
	public RegisterMgr1() {
		try {
			Class.forName(JDBC_DRIVER);
	}catch(ClassNotFoundException e){
			System.out.println("����: JDBC ����̹� �ε� ����.");
			e.printStackTrace();
	}
	}	
	public Vector<RegisterBean> getRegisterList(){
		Connection conn = null;
		ResultSet rs = null;
		Statement stmt = null;
		
		Vector<RegisterBean> vlist = new Vector<RegisterBean>();
		
		try {
			conn = DriverManager.getConnection(JDBC_URL, USER, PASS);
			String strQuery = "select * from tblRegister";
			stmt = conn.createStatement();
			rs = stmt.executeQuery(strQuery);
			while(rs.next()) {
				RegisterBean bean = new RegisterBean();
				bean.setId(rs.getString("id"));
				bean.setPwd(rs.getString("passwd"));
				bean.setName(rs.getString("name"));
				vlist.add(bean);
			}
		}catch(Exception e) {
	          System.out.println("Exception" + e);
		}finally{
			if(rs != null) try {rs.close();} catch(SQLException e) {}
			if(stmt != null) try {rs.close();} catch(SQLException e) {}
			if(conn != null) try {rs.close();} catch(SQLException e) {}

		}
		return vlist;
	}

}
