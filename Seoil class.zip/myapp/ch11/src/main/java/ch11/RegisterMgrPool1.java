package ch11;

 import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;
 
 public class RegisterMgrPool1 {
    private DBConnectionMgr pool = null; 
	 
 	public RegisterMgrPool1() {
 	 try{
 		 pool = DBConnectionMgr.getInstance();
 		 
 	 }catch(Exception e){
 	      System.out.println("Error : ConnectionPool ���� ����.");
 	      e.printStackTrace();
 	   }
     }
 
    public Vector<RegisterBean> getRegisterList() {
	   Connection conn = null;
	   Statement stmt = null;
       ResultSet rs = null;
       Vector<RegisterBean> vlist = new Vector<RegisterBean>();
       try {
          conn = pool.getConnection();
          String strQuery = "select * from tblRegister";
          stmt = conn.createStatement();
          rs = stmt.executeQuery(strQuery);
		  while (rs.next()) {
             RegisterBean bean = new RegisterBean();
		 	 bean.setId (rs.getString("id"));
			 bean.setPwd (rs.getString("passwd"));
 			 bean.setName (rs.getString("name"));
				
 			 vlist.addElement(bean);
          }
       } catch (Exception ex) {
          System.out.println("Exception" + ex);
       } finally {
    	   pool.freeConnection(conn, stmt, rs);
       }
       return vlist;
    }
 }