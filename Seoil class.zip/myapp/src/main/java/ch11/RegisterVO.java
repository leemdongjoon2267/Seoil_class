package myapp.ch11;

public class RegisterVO {
	private String userId;
	private String userPwd;
	private String userName;
	private String regNum1;
	private String regNum2;
	private String email;
	private String phone;
	private String zipcode;
	private String address;
	private String job;
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getUserPwd() {
		return userPwd;
	}
	public void setUserPwd(String userPwd) {
		this.userPwd = userPwd;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserNm(String userName) {
		this.userName = userName;
	}
	public String getRegNum1() {
		return regNum1;
	}
	public void setRegNum1(String regNum1) {
		this.regNum1 = regNum1;
	}
	public String getRegNum2() {
		return regNum2;
	}
	public void setRegNum2(String regNum2) {
		this.regNum2 = regNum2;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getZipcode() {
		return zipcode;
	}
	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getJob() {
		return job;
	}
	public void setJob(String job) {
		this.job = job;
	}
	
	
}
