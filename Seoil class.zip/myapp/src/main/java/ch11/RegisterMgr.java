package myapp.ch11;

import java.sql.*;
import java.util.Vector;

public class RegisterMgr {
	private final String JDBC_DRIVER = "oracle.jdbc.driver.OracleDriver";
	private final String JDBC_URL ="jdbc:oracle:thin:@localhost:1521:xe";
	private final String USER ="HR";
	private final String PWD ="1234";
	
	public RegisterMgr() { // 생성자
		try {
			Class.forName(JDBC_DRIVER); // JDBC_DRIVER를 로딩
		}catch(Exception e) {
			System.out.println("Error : JDBC 드라이버 로딩 실패 ");
			e.printStackTrace();
		}
	}
	
	public Vector<RegisterVO> getRegisterList() {
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		Vector<RegisterVO> vList = new Vector<RegisterVO>();
		try {
			conn = DriverManager.getConnection(JDBC_URL, USER, PWD); // DB연결
			String query = "SELECT * FROM TB_REGISTER";
			stmt = conn.createStatement();
			rs = stmt.executeQuery(query);
			
			while(rs.next()) {
				RegisterVO regVO = new RegisterVO();
				regVO.setUserId(rs.getString("USER_ID"));
				regVO.setUserPwd(rs.getString("USER_PWD"));
				regVO.setUserNm(rs.getString("USER_NAME"));
				regVO.setRegNum1(rs.getString("REG_NUM1"));
				regVO.setRegNum2(rs.getString("REG_NUM2"));
				regVO.setEmail(rs.getString("EMAIL"));
				regVO.setPhone(rs.getString("PHONE"));
				regVO.setZipcode(rs.getString("ZIPCODE"));
				regVO.setAddress(rs.getString("ADdRESS"));
				regVO.setJob(rs.getString("JOB"));
				vList.add(regVO);
			}
			
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			if(rs!=null ) {
				try {
					rs.close();
				}catch(SQLException e) {}
			}
			if(stmt!=null) {
				try {
					stmt.close();
				}catch(SQLException e) {}
			}
			if(conn!=null) {
				try {
					conn.close();
				} catch(SQLException e) {}
			}
		}
		return vList;
	}
}
