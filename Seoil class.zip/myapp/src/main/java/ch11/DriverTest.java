package myapp.ch11;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DriverTest {

	public static void main(String[] args) {
		Connection con;
		String url ="jdbc:oracle:thin:@localhost:1521:xe"; // 연결 url
		String id = "HR"; // url에 연결하기 위한 아이디
		String pw = "1234";
		
		try {
			// JDBC 드라이버 로딩
			Class.forName("oracle.jdbc.driver.OracleDriver"); //데이터베이스를 연결하게끔 해줌
			con = DriverManager.getConnection(url, id, pw); // url에 id, pw를 가지고 연결
			System.out.println(con.isClosed()?"접속종료":"접속중");
			
			con.close();
			
			System.out.println(con.isClosed()?"접속종료":"접속중");
			
			
		}catch(SQLException ex) {
			System.out.println("SQLException :" + ex);
			
		}catch(Exception e) {
			System.out.println("Exception :" + e);
			e.printStackTrace();
		}
	}

}
